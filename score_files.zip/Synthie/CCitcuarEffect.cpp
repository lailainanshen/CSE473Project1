#include "stdafx.h"
#include "CCitcuarEffect.h"
#include "Resource.h"

CCitcuarEffect::CCitcuarEffect(void)
{
	inList.resize(15000);
	outList.resize(15000);
	wrloc = 0;
}


CCitcuarEffect::~CCitcuarEffect(void)
{
}